
Joda-Time
=========
Joda-Time is a date and time library that vastly improves on the JDK.

See the home page for more details:
http://joda-time.sourceforge.net/

The source code is held primarily at GitHub:
https://github.com/JodaOrg/joda-time

Related projects at GitHub:
https://github.com/JodaOrg/joda-time-hibernate
https://github.com/JodaOrg/joda-time-jsptags
https://github.com/JodaOrg/joda-time-i18n

Other related projects:
http://joda-time.sourceforge.net/related.html
