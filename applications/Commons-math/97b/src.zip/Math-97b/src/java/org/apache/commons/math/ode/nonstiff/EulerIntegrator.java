/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.math.ode.nonstiff;

/**
 * This class implements a simple Euler integrator for Ordinary
 * Differential Equations.
 *
 * <p>The Euler algorithm is the simplest one that can be used to
 * integrate ordinary differential equations. It is a simple inversion
 * of the forward difference expression :
 * <code>f'=(f(t+h)-f(t))/h</code> which leads to
 * <code>f(t+h)=f(t)+hf'</code>. The interpolation scheme used for
 * dense output is the linear scheme already used for integration.</p>
 *
 * <p>This algorithm looks cheap because it needs only one function
 * evaluation per step. However, as it uses linear estimates, it needs
 * very small steps to achieve high accuracy, and small steps lead to
 * numerical errors and instabilities.</p>
 *
 * <p>This algorithm is almost never used and has been included in
 * this package only as a comparison reference for more useful
 * integrators.</p>
 *
 * @see MidpointIntegrator
 * @see ClassicalRungeKuttaIntegrator
 * @see GillIntegrator
 * @see ThreeEighthesIntegrator
 * @version $Revision$ $Date$
 * @since 1.2
 */

public class EulerIntegrator
  extends RungeKuttaIntegrator {

  /** Serializable version identifier. */
  private static final long serialVersionUID = -3378479003330094013L;

  /** Integrator method name. */
  private static final String methodName = "Euler";

  /** Time steps Butcher array. */
  private static final double[] c = {
  };

  /** Internal weights Butcher array. */
  private static final double[][] a = {
  };

  /** Propagation weights Butcher array. */
  private static final double[] b = {
    1.0
  };

  /** Simple constructor.
   * Build an Euler integrator with the given step.
   * @param step integration step
   */
  public EulerIntegrator(final double step) {
    super(c, a, b, new EulerStepInterpolator(), step);
  }

  /** {@inheritDoc} */
  public String getName() {
    return methodName;
  }

}
